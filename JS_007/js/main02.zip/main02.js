const inputs = document.querySelectorAll("input");
const tbodyAddr = document.querySelector("tbody.addr");
const btnAdd = document.querySelector("button.add");

let addrList = [];
const addrLoad = () => {
  const strAddr = localStorage.getItem("myAddr");

  addrList = JSON.parse(strAddr);
  console.log("가져온 데이터 확인");
  console.table(addrList);
  if (!addrList) {
    addrList = [];
    return false;
  }
  for (i = 0; i < addrList.length; i++) {
    const tr = document.createElement("TR");
    let td = document.createElement("TD");
    td.textContent = addrList[i].name;
    tr.appendChild(td);

    td = document.createElement("TD");
    td.textContent = addrList[i].addr;
    tr.appendChild(td);

    td = document.createElement("TD");
    td.textContent = addrList[i].tel;
    tr.appendChild(td);

    tbodyAddr.appendChild(tr);
  }
};
const addrCheck = () => {
  for (let i = 0; i < inputs.length; i++) {
    const input = inputs[i];
    const holderText = inputs[i].placeholder;
    if (!input.value) {
      alert(`${holderText}를 입력하세요`);
      input.value = "";
      input.focus();
      return false;
    }
  }
  for (let i = 2; i < inputs.length; i++) {
    const input = inputs[i];
    const holderText = inputs[i].placeholder;
    if (!input.value) {
      alert(`${input.placeholder} 를(을) 입력하세요`);
    } else if (Number(input.value) < 0 || Number(input.value) > 100) {
      alert(`${holderText}점수는 0 ~ 100 까지 입력하세요`);
    } else if (!Number(input.value)) {
      alert(`${holderText}점수는 숫자로만 입력해주세요`);
    } else {
      continue;
    }
    input.focus();
    return false;
  }
  return true;
};

btnAdd?.addEventListener("click", () => {
  if (addrCheck()) {
    addrInput();
  }
});
